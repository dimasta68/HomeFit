<?php
use Refactoring14\JetBrains\CoolPerson;

require_once '../01_Refactor_This.php';
require_once '../13_Rename.php';
require_once '../14_Safe_Delete.php';

$coolPerson = new CoolPerson('Maarten');
