<?php
/**
 * Copy
 *
 * F5 (copy) (Windows/Linux/macOS)
 *
 *
 * Copy a class, file or directory to another directory.
 */

namespace Refactoring3\JetBrains;

// 1. Copy the 01_Refactor_This.php file to the Code directory.
//    Do this from the Project Tool Window and do not touch the mouse.
//    HINT: Alt+1/Command+1, arrow keys, F5
// 2. Copy the current file to the Code directory. Drag/drop it using Ctrl key pressed.
