<?php
/**
 * Creating Live Template From Editor
 */

namespace LiveTemplates2\JetBrains;

// 1. Select the following 2 lines of code:
echo "$TEXT$";
$END$

// 2. Use the Tools | Save as Live Template... menu.
// 3. Save the template as 'e'.
// 4. Test the template.

// e <TAB>
