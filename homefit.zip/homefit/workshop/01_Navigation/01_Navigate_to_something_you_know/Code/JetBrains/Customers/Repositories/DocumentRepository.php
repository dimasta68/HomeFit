<?php
namespace Navigation1\JetBrains\Customers\Repositories;


class DocumentRepository extends RepositoryBase {

}
