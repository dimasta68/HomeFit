var Customer = function() {
    this.name = '';
    this.age = 0;
    this.celebrateBirthday = function() {
        console.log('Yay!');
    }
};
