<?php
namespace Navigation1\JetBrains\Customers\Repositories;


abstract class RepositoryBase {

}
