<?php
namespace Navigation1\JetBrains\Customers\Repositories;


class SettingsRepository extends RepositoryBase {

}
