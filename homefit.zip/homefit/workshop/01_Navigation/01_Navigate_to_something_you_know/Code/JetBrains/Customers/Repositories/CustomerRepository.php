<?php
namespace Navigation1\JetBrains\Customers\Repositories;


class CustomerRepository extends RepositoryBase {

}
