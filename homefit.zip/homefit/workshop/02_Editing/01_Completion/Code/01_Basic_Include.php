<?php

function completionRocks()
{
}